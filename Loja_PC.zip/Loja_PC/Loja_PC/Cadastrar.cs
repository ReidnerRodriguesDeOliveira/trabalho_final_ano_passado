﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loja_PC
{
    public partial class Cadastrar : Form
    {
        public Cadastrar()
        {
            InitializeComponent();
        }

        #region ConexaoBD
        ConexaoBD bd = new ConexaoBD();
        string sql;
        #endregion


        public void limpar()
        {
            txtCriarNome.Clear();
            txtCriarSenha.Clear();
            txtConfirmarSenha.Clear();
            txtCriarEmail.Clear();

        }

        private void btnCadastarConta_Click(object sender, EventArgs e)
        {
            if (txtCriarNome.Text == "" || txtCriarSenha.Text == "" || txtConfirmarSenha.Text == "" || txtCriarEmail.Text == "")
            {
                MessageBox.Show("Preencha Todas as Informações!", "Informações Incompletas", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                if (txtCriarSenha.Text != txtConfirmarSenha.Text)
                    MessageBox.Show("Senhas Incorretas!", "Senha Incorreta", MessageBoxButtons.OK, MessageBoxIcon.Error);

                else
                {
                    MessageBox.Show("Cadastro de Conta TechTrab Concluido Com Sucesso!!", "Cadastro Com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.Close();
                    sql = string.Format("insert into cadastro_vs values(null,'{0}','{1}','{2}','{3}')", txtCriarNome.Text, txtCriarSenha.Text, txtConfirmarSenha.Text, txtCriarEmail.Text);
                    bd.AlterarDados(sql);
                    limpar();
                }
            }
        }

        private void btnLimparCadastro_Click(object sender, EventArgs e)
        {
            limpar();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Cadastrar_Load(object sender, EventArgs e)
        {

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();


            sql = string.Format("delete from cadastro_vs where nome = '{0}' and email = '{1}' and senha = '{2}'", txtCriarNome.Text, txtCriarEmail.Text, txtCriarSenha.Text);
            dt = bd.ConsultarDados(sql);
            MessageBox.Show("Conta Deletada Com Sucesso!", "Conta Deletada", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            limpar();


            if (txtCriarNome.Text != "nome" && txtCriarSenha.Text == "" && txtConfirmarSenha.Text == "" && txtCriarEmail.Text == "")
            {

            }

            if (dt.Rows.Count > 0)
            {
                string nome;
                sql = string.Format("delete from cadastro_vs where nome = '{0}'", txtCriarNome.Text);
                dt = bd.ConsultarDados(sql);
                nome = dt.Rows[0]["nome"].ToString();
            }
        }

        private void txtCriarEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCriarSenha_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
