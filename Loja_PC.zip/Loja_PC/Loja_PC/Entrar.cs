﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loja_PC
{
    public partial class Entrar : Form
    {
        public Entrar()
        {
            InitializeComponent();
        }

        #region ConexaoBD
        ConexaoBD bd = new ConexaoBD();
        string sql;
        #endregion


        private void btnEntrar_Click(object sender, EventArgs e)
        {


            DataTable dt = new DataTable();
            //' or 1=1#-
            if (txtEntrarNome.Text == string.Empty || txtEntrarSenha.Text == string.Empty || txtEntrarEmail.Text == string.Empty)
            {
                MessageBox.Show("Preencha Todas As Informações! ", "Login Incorreto", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                sql = string.Format("select * from cadastro_vs where nome = '{0}' and senha = '{1}' and email = '{2}'", txtEntrarNome.Text, txtEntrarSenha.Text, txtEntrarEmail.Text);
                dt = bd.ConsultarDados(sql);

                if (dt.Rows.Count > 0)
                {
                    sql = string.Format("select * from cadastro_vs where nome = '{0}'", txtEntrarNome.Text);
                    dt = bd.ConsultarDados(sql);
                    MessageBox.Show("Bem-Vindo a TechTrab " + txtEntrarNome.Text + "!", "Login", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);


                    this.Visible = false;
                    frmPaginaInicial ABRIR = new frmPaginaInicial();
                    ABRIR.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Login Incorreto!", "Login Incorreto!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

            //MessageBox.Show("Cadastro da conta Concluido Com Sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            //this.Close();



            //frmPaginaInicial abrirpaginainicial = new frmPaginaInicial();
            //abrirpaginainicial.Show();

            /* Pagina paginainicialform = new AdicionarProduto();
             paginainicialform.Show();*/
        }
        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Cadastrar cad = new Cadastrar();
            cad.ShowDialog();
            this.Visible = true;
            txtEntrarNome.Clear();
            txtEntrarSenha.Clear();
            txtEntrarEmail.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtEntrarEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void Entrar_Load(object sender, EventArgs e)
        {
        }
    }
}
