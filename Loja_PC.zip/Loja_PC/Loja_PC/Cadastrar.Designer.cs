﻿namespace Loja_PC
{
    partial class Cadastrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCadastarConta = new System.Windows.Forms.Button();
            this.lblSenha = new System.Windows.Forms.Label();
            this.txtCriarSenha = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtCriarEmail = new System.Windows.Forms.TextBox();
            this.lblCriarNome = new System.Windows.Forms.Label();
            this.txtCriarNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtConfirmarSenha = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnLimparCadastro = new System.Windows.Forms.Button();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCadastarConta
            // 
            this.btnCadastarConta.FlatAppearance.BorderSize = 0;
            this.btnCadastarConta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.btnCadastarConta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.btnCadastarConta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastarConta.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastarConta.Location = new System.Drawing.Point(107, 192);
            this.btnCadastarConta.Name = "btnCadastarConta";
            this.btnCadastarConta.Size = new System.Drawing.Size(240, 36);
            this.btnCadastarConta.TabIndex = 5;
            this.btnCadastarConta.Text = "Cadastar Conta";
            this.btnCadastarConta.UseVisualStyleBackColor = true;
            this.btnCadastarConta.Click += new System.EventHandler(this.btnCadastarConta_Click);
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenha.Location = new System.Drawing.Point(101, 111);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(43, 16);
            this.lblSenha.TabIndex = 12;
            this.lblSenha.Text = "Senha";
            // 
            // txtCriarSenha
            // 
            this.txtCriarSenha.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCriarSenha.Location = new System.Drawing.Point(205, 109);
            this.txtCriarSenha.Name = "txtCriarSenha";
            this.txtCriarSenha.Size = new System.Drawing.Size(142, 21);
            this.txtCriarSenha.TabIndex = 2;
            this.txtCriarSenha.UseSystemPasswordChar = true;
            this.txtCriarSenha.TextChanged += new System.EventHandler(this.txtCriarSenha_TextChanged);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(104, 168);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(40, 16);
            this.lblEmail.TabIndex = 14;
            this.lblEmail.Text = "E-mail";
            // 
            // txtCriarEmail
            // 
            this.txtCriarEmail.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCriarEmail.Location = new System.Drawing.Point(205, 166);
            this.txtCriarEmail.Name = "txtCriarEmail";
            this.txtCriarEmail.Size = new System.Drawing.Size(142, 21);
            this.txtCriarEmail.TabIndex = 4;
            this.txtCriarEmail.TextChanged += new System.EventHandler(this.txtCriarEmail_TextChanged);
            // 
            // lblCriarNome
            // 
            this.lblCriarNome.AutoSize = true;
            this.lblCriarNome.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCriarNome.Location = new System.Drawing.Point(101, 83);
            this.lblCriarNome.Name = "lblCriarNome";
            this.lblCriarNome.Size = new System.Drawing.Size(40, 16);
            this.lblCriarNome.TabIndex = 16;
            this.lblCriarNome.Text = "Nome";
            // 
            // txtCriarNome
            // 
            this.txtCriarNome.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCriarNome.Location = new System.Drawing.Point(205, 81);
            this.txtCriarNome.Name = "txtCriarNome";
            this.txtCriarNome.Size = new System.Drawing.Size(142, 21);
            this.txtCriarNome.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(101, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Confirmar Senha";
            // 
            // txtConfirmarSenha
            // 
            this.txtConfirmarSenha.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmarSenha.Location = new System.Drawing.Point(205, 140);
            this.txtConfirmarSenha.Name = "txtConfirmarSenha";
            this.txtConfirmarSenha.Size = new System.Drawing.Size(142, 21);
            this.txtConfirmarSenha.TabIndex = 3;
            this.txtConfirmarSenha.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(35, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Crie a sua Conta Aqui!";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(104, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(243, 50);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            // 
            // btnLimparCadastro
            // 
            this.btnLimparCadastro.FlatAppearance.BorderSize = 0;
            this.btnLimparCadastro.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.btnLimparCadastro.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.btnLimparCadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimparCadastro.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimparCadastro.Location = new System.Drawing.Point(107, 274);
            this.btnLimparCadastro.Name = "btnLimparCadastro";
            this.btnLimparCadastro.Size = new System.Drawing.Size(240, 36);
            this.btnLimparCadastro.TabIndex = 7;
            this.btnLimparCadastro.Text = "Limpar";
            this.btnLimparCadastro.UseVisualStyleBackColor = true;
            this.btnLimparCadastro.Click += new System.EventHandler(this.btnLimparCadastro_Click);
            // 
            // btnVoltar
            // 
            this.btnVoltar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnVoltar.FlatAppearance.BorderSize = 0;
            this.btnVoltar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.btnVoltar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.btnVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVoltar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltar.Location = new System.Drawing.Point(107, 232);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(240, 36);
            this.btnVoltar.TabIndex = 6;
            this.btnVoltar.Text = "Voltar";
            this.btnVoltar.UseVisualStyleBackColor = true;
            this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Loja_PC.Properties.Resources.TechTrabLogo;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(79, 54);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // Cadastrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 313);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnVoltar);
            this.Controls.Add(this.btnLimparCadastro);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtConfirmarSenha);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCriarNome);
            this.Controls.Add(this.lblCriarNome);
            this.Controls.Add(this.txtCriarEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtCriarSenha);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.btnCadastarConta);
            this.MaximizeBox = false;
            this.Name = "Cadastrar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar";
            this.Load += new System.EventHandler(this.Cadastrar_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCadastarConta;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.TextBox txtCriarSenha;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtCriarEmail;
        private System.Windows.Forms.Label lblCriarNome;
        private System.Windows.Forms.TextBox txtCriarNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtConfirmarSenha;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnLimparCadastro;
        private System.Windows.Forms.Button btnVoltar;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}