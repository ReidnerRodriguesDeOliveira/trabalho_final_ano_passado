﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loja_PC
{
    public partial class AdicionarProduto : Form
    {
        public AdicionarProduto()
        {
            InitializeComponent();
        }

        #region ConexaoBD
        ConexaoBD bd = new ConexaoBD();
        DataTable dt;
        string sql;
        #endregion

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void listar()
        {
            sql = "Select * from produtos";
            grdEstoque.DataSource = bd.ConsultarDados(sql);
        }
        public void limpar()
        {
            txtNomeProduto.Clear();
            cbxTipo.SelectedIndex = -1;
            txtMarca.Clear();
            txtPreco.Clear();
            cbxTamanho.SelectedIndex = -1;
        }

        private void btnCadastrarProdutos_Click(object sender, EventArgs e)
        {
            //data = DateTime.Parse(grdEstoque.Text);
            //verificar no banco de dados se o codigo ja existe, se existir, ele n pode ser adicionado

            //adicionar data/horas no grid

            //MessageBox.Show("Não é possivel adicionar esse produto!!", "Cadastro de Produto Inválido!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            if (cbxTipo.Text == "" || txtMarca.Text == "" || txtPreco.Text == "" || cbxTamanho.Text == "" || txtNomeProduto.Text == "")
            {
                MessageBox.Show("Escreva os Dados Primeiros Antes de Adicionar Algum!", "Adicionando Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                sql = string.Format("insert into produtos values(null,'{0}','{1}','{2}','{3}','{4}')", txtNomeProduto.Text, cbxTipo.Text, txtMarca.Text, txtPreco.Text, cbxTamanho.Text);
                bd.AlterarDados(sql);/*(null,'','Placa de Vídeo','','','Pequeno')' */
                MessageBox.Show("Dados do Produto Cadastrado!", "Cadastro de Produto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                limpar();
                listar();
                txtNomeProduto.Focus();
            }

        }


        //sql = string.Format("delete from alunos where matricula = '{0}'", txtMatricula.Text);
        //bd.AlterarDados(sql);
        //    MessageBox.Show("Dados do Aluno Excluído com Sucesso!","Alunos",MessageBoxButtons.OK,MessageBoxIcon.Information);
        //    limpar();
        //listar();

        private void txtPreco_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
        }

        private void AdicionarProduto_Load(object sender, EventArgs e)
        {
            listar();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            limpar();
            txtNomeProduto.Focus();
        }

        private void btnExcluirProd_Click(object sender, EventArgs e)
        {

            if (txtCodFuncao.Text != "")
            {

                //MessageBox.Show("Você Realmente Deseja Excluir Os Dados Do Produto?","Exclusão de Produtos",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
                sql = string.Format("delete from produtos where codigo = '{0}'", txtCodFuncao.Text);
                if (bd.AlterarDados(sql) > 0)
                {
                    if(MessageBox.Show("Você Tem Certeza que Deseja Excluir os Dados do Produto?", "Exclusão de Produtos!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        MessageBox.Show("Dados do Produto Excluído com Sucesso!", "Exclusão de Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Dados Não Excluidos!", "Exclusão de Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    limpar();
                    listar();
                    txtCodFuncao.Focus();
                }

                else
                    MessageBox.Show("Código de Produto inexistente!", "Exclusão de Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
                MessageBox.Show("Digite um Código Existente!", "Exclusão de Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void grdEstoque_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }



        private void txtPreco_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnEditarProd_Click(object sender, EventArgs e)
        {
            DataTable buscar = new DataTable();
            buscar = bd.ConsultarDados(sql);

            if (cbxTipo.Text == "" || txtMarca.Text == "" || txtPreco.Text == "" || cbxTamanho.Text == "" || txtNomeProduto.Text == "")
                MessageBox.Show("Escreva os Dados Primeiros Antes de Editar Algum!", "Editando Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            else if (txtCodFuncao.Text != "")
            {
                sql = string.Format("update produtos set nome = '{0}', tipo = '{1}', marca = '{2}', preco = '{3}', tamanho = '{4}' where codigo = '{5}'"
                    , txtNomeProduto.Text, cbxTipo.Text, txtMarca.Text, txtPreco.Text, cbxTamanho.Text, txtCodFuncao.Text);
                bd.AlterarDados(sql);

                if (bd.AlterarDados(sql) > 0)
                {
                    MessageBox.Show("Dados do Produto Atualizados com Sucesso!", "Atualização de Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpar();
                    listar();
                    txtNomeProduto.Focus();
                    #region
                    //txtCodFuncao.Text = buscar.Rows[0]["codigo"].ToString();
                    //MessageBox.Show("Código Não Existe!", "Editar Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //sql = string.Format("select * from produtos where codigo = '{0}'", txtCodFuncao.Text);
                    //buscar = bd.ConsultarDados(sql);

                    //MessageBox.Show("Dados do Produto Editados com Sucesso!", "Editar Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //limpar();
                    //listar();
                    //txtCodFuncao.Focus();
                    #endregion
                }

                else
                    MessageBox.Show("Código de Produto inexistente!", "Editar Produtos!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}


