﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loja_PC
{
    public partial class frmPaginaInicial : Form
    {
        public frmPaginaInicial()
        {
            InitializeComponent();
        }

        ConexaoBD bd = new ConexaoBD();
        string sql;
        
        
        private void button2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            AdicionarProduto addprod = new AdicionarProduto();
            addprod.ShowDialog();
            this.Visible = true;


        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            AdicionarProduto novaform = new AdicionarProduto();
            novaform.Show();
        }

        private void btnExcluirProd_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Deseja Excluir o Produto Selecionado?","Excluir Produto da Lista",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
        }

        private void btnEditarProd_Click(object sender, EventArgs e)
        {

        }

        private void btnPesqProduto_Click(object sender, EventArgs e)
        {

        }

        private void btnOutraAcc_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Entrar pi = new Entrar();
            pi.ShowDialog();

        }
    }
}
