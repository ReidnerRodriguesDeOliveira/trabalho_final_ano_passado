CREATE DATABASE TechTrab;
USE TechTrab;

Create table clientes(
  codigo int(10) unsigned not null auto_increment,
  nome varchar(45) not null,
  endereco varchar(45) not null,
  cpf char(14) not null,
  rg char(15) not null,
  primary key(codigo));
   
Create table produtos(
  codigo int(100) auto_increment not null,
  nome varchar(45) not null,
  tipo varchar(45) not null,
  marca varchar(14) not null,
  preco double(9,2) not null,
  tamanho varchar(15) not null,
  primary key(codigo));
   
Create table funcionarios(
  codigo int(10) unsigned not null,
  nome varchar(45) not null,
  cpf char(14) not null,
  login varchar(40) not null,
  senha varchar(40) not null,
  primary key(codigo));  
   
Create table vendas(
 codigo int(10) unsigned not null auto_increment,
 data_venda date not null,
 observacao varchar(90) not null,
 total varchar(15) not null,
 clientes_codigo varchar(15) not null,
 produtos_codigo varchar(15) not null,
 funcionarios_codigo varchar(15) not null,
 primary key(codigo),
 foreign key (clientes_codigo) references clientes(codigo),
 foreign key (produtos_codigo) references produtos(codigo),
 foreign key (funcionarios_codigo) references funcionarios(codigo));
 
Create table cadastro_vs(
	codigo int(10)unsigned auto_increment not null,
    nome varchar(100) not null,
    senha varchar(100) not null,
    confirmar_senha varchar (100) not null,
    email varchar(100) not null,
    primary key(codigo));
    
    

Create table login_vs(
	codigo int(10)unsigned auto_increment not null,
    nome varchar(100) not null,
    email varchar(100) not null,
    senha varchar(100) not null,
    cadastro_codigo int not null,
    foreign key (cadastro_codigo) references cadastro(codigo),
    primary key(codigo));	



 
 
 
select * from cadastro_vs;
select * from login_vs;
select * from produtos;
 
delete from cadastro_vs where codigo = '';
delete from produtos where codigo = '36';
 
  